
/// <reference path="threejs/three.d.ts" />
/// <reference path="dat-gui/dat-gui.d.ts" />
/// <reference path="../Scripts/objects/control.ts" />
/// <reference path="stats/stats.d.ts" />
