* to a nice visual test demo

### File hierachy
threex.colliderSystem.js
threex.collider.js


### What need to be tested
* creation during contact
* removal during contact
* during non contact


- do a static object in the middle
- a moving object from left to right
- by tunning where the moving object start and finish
- you can recreate all the case
- there is like 4 of theml