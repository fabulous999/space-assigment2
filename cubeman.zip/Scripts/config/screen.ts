module config {
    export class Screen {
        static WIDTH:number = 640;
        static HEIGHT:number = 480;
        static RATIO:number = 1.333333;
    }
    
}