/// <reference path="_reference.ts"/>

// MAIN GAME FILE

// THREEJS Aliases
import Scene = THREE.Scene;
import Renderer = THREE.WebGLRenderer;
import PerspectiveCamera = THREE.PerspectiveCamera;
import BoxGeometry = THREE.BoxGeometry;
import CubeGeometry = THREE.CubeGeometry;
import PlaneGeometry = THREE.PlaneGeometry;
import SphereGeometry = THREE.SphereGeometry;
import Geometry = THREE.Geometry;
import AxisHelper = THREE.AxisHelper;
import LambertMaterial = THREE.MeshLambertMaterial;
import MeshBasicMaterial = THREE.MeshBasicMaterial;
import Material = THREE.Material;
import Mesh = THREE.Mesh;
import Object3D = THREE.Object3D;
import SpotLight = THREE.SpotLight;
import PointLight = THREE.PointLight;
import AmbientLight = THREE.AmbientLight;
import Control = objects.Control;
import GUI = dat.GUI;
import Color = THREE.Color;
import Vector3 = THREE.Vector3;
import Face3 = THREE.Face3;
import Point = objects.Point;
import CScreen = config.Screen;

import Control2 = objects.Control;
//Custom Game Objects
import gameObject = objects.gameObject;
var loader = new THREE.JSONLoader();
var animation;
var scene: Scene;
var renderer: Renderer;
var camera: PerspectiveCamera;
var axes: AxisHelper;
var cube: Mesh;
var plane: Mesh;
var sphere: Mesh;
var ambientLight: AmbientLight;
var spotLight: SpotLight;
var control: Control;
var control2: Control2;
var gui: GUI;
var stats: Stats;
var step: number = 0;
var cubeGeometry: CubeGeometry;
var armeMaterial: LambertMaterial;
var arm2eMaterial: LambertMaterial;
var legMaterial: LambertMaterial;
var leg2Material: LambertMaterial;
var headMaterial: LambertMaterial;
var cubeMaterial: LambertMaterial;
var ambientColour;
var head: Mesh;
var leg: Mesh;
var leg2: Mesh;
var arm: Mesh;
var arm2: Mesh;
var legGeometry: CubeGeometry;
var armGeometry: CubeGeometry;
var headGeometry: CubeGeometry;
var material = new THREE.MeshPhongMaterial( { map: THREE.ImageUtils.loadTexture('texture/pl_sun.jpg') } );
 var texture = new THREE.MeshPhongMaterial( { map: THREE.ImageUtils.loadTexture('texture/crate.jpg') } );
var i;
var j;


function init() {
    // Instantiate a new Scene object
    scene = new Scene();

    setupRenderer(); // setup the default renderer
	
    setupCamera(); // setup the camera
	
    // add an axis helper to the scene
    axes = new AxisHelper(10);
    scene.add(axes);
    console.log("Added Axis Helper to scene...");
   
    //Add a Plane to the Scene
   // plane = new gameObject(
     //   new PlaneGeometry(16, 16, 1, 1),material, 0, 0, 0);
         plane = new gameObject(
        new PlaneGeometry(20, 40, 1, 1), texture ,1, 1, 1);
    plane.rotation.x = -0.5 * Math.PI;
    scene.add(plane);
    console.log("Added Plane Primitive (Floor) to Scene");
       //
//
    plane.rotation.x = -0.5 * Math.PI;

    scene.add(plane);
    console.log("Added Plane Primitive to scene...");
    
    //Add a Cube to the Scene
        
    ambientColour = "#0c0c0c";
    cubeMaterial = new LambertMaterial(ambientColour);
    legMaterial = new LambertMaterial(ambientColour);
    leg2Material = new LambertMaterial(ambientColour);
    arm2eMaterial = new LambertMaterial(ambientColour);
    armeMaterial = new LambertMaterial(ambientColour);
    headMaterial = new LambertMaterial(ambientColour);
    //cubeMaterial = new LambertMaterial({color:0x00ff00});
    cubeGeometry = new CubeGeometry(2, 3, 2);
    cube = new Mesh(cubeGeometry, cubeMaterial);
    cube.castShadow = true;
    cube.receiveShadow = true;
    cube.position.set(0, 5, 0);

    legGeometry = new CubeGeometry(1, 3, 1);
    leg = new Mesh(legGeometry, legMaterial);
    leg.castShadow = true;
    leg.receiveShadow = true;
    leg.position.set(0.8, -3, 0);

    leg2 = new Mesh(legGeometry, leg2Material);
    leg2.castShadow = true;
    leg2.receiveShadow = true;
    leg2.position.set(-0.8, -3, 0);

    armGeometry = new CubeGeometry(1, 2, 1);
    arm = new Mesh(armGeometry, arm2eMaterial);
    arm.castShadow = true;
    arm.receiveShadow = true;
    arm.position.set(1.5, 0.5, 0);

    arm2 = new Mesh(armGeometry, armeMaterial);
    arm2.castShadow = true;
    arm2.receiveShadow = true;
    arm2.position.set(-1.5, 0.5, 0);

    headGeometry = new CubeGeometry(1, 1, 1);
    head = new Mesh(headGeometry, headMaterial);
    head.castShadow = true;
    head.receiveShadow = true;
    head.position.set(0, 2, 0);



    cube.add(leg);
    cube.add(leg2);
    cube.add(arm2);
    cube.add(arm);
    cube.add(head);

    scene.add(cube);

    console.log("Added Cube Primitive to scene...");
    
    var render = function () {
				requestAnimationFrame( render );
             
                arm.rotation.x += 0.05;
				arm2.rotation.x += 0.05;
			//renderer.render(scene, camera);
			};

			render();

    //  ambientLight = new AmbientLight(ambientColour);
    // Add an AmbientLight to the scene
    ambientLight = new AmbientLight(0x090909);
    scene.add(ambientLight);
    console.log("Added an Ambient Light to Scene");
	
    // Add a SpotLight to the scene
    spotLight = new SpotLight(0xffffff);
    spotLight.position.set(-40, 60, 10);
    spotLight.rotation.set(-0.8, 42.7, 19.5);
    spotLight.castShadow = true;
    scene.add(spotLight);
    console.log("Added a SpotLight Light to Scene");
    
    // add controls
    gui = new GUI();
    //  control = new Control(0.05);
    control = new Control(0.00, ambientColour);
    addControl(control);

    // Add framerate stats
    addStatsObject();
    console.log("Added Stats to scene...");

    document.body.appendChild(renderer.domElement);
    gameLoop(); // render the scene	
    
    window.addEventListener('resize', onResize, false);
}

function onResize(): void {
    camera.aspect = CScreen.RATIO;
    //camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    //renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setSize(CScreen.WIDTH, CScreen.HEIGHT);
}
function addControl(controlObject: Control): void {
    gui.add(controlObject, 'rotationSpeedx', -0.5, 0.5);
    gui.add(controlObject, 'rotationSpeedy', -0.5, 0.5);
    gui.add(controlObject, 'rotationSpeedz', -0.5, 0.5);
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { cubeMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { legMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { leg2Material.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { arm2eMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { armeMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange((color) => { headMaterial.color = new Color(color); });
    /* armeMaterial = new LambertMaterial(ambientColour);*/
}




function addStatsObject() {
    stats = new Stats();
    stats.setMode(0);
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.left = '0px';
    stats.domElement.style.top = '0px';
    document.body.appendChild(stats.domElement);
}

// Setup main game loop
function gameLoop(): void {
    stats.update();

    cube.rotation.x += control.rotationSpeedx;
    cube.rotation.y += control.rotationSpeedy;
    cube.rotation.z += control.rotationSpeedz;
    
    
    // render using requestAnimationFrame
    requestAnimationFrame(gameLoop);
	
    // render the scene
    renderer.render(scene, camera);
}

// Setup default renderer
function setupRenderer(): void {
    renderer = new Renderer();
    renderer.setClearColor(0xEEEEEE, 1.0);
    renderer.setSize(CScreen.WIDTH, CScreen.HEIGHT);
    //renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    console.log("Finished setting up Renderer...");
}

// Setup main camera for the scene
function setupCamera(): void {
    camera = new PerspectiveCamera(45, config.Screen.RATIO, 0.1, 1000);
    //camera = new PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.x = 0.6;
    camera.position.y = 16;
    camera.position.z = -20.5;
    camera.lookAt(new Vector3(0, 0, 0));
    console.log("Finished setting up Camera...");
}
