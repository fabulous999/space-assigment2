/// <reference path="_reference.ts"/>
// MAIN GAME FILE
// THREEJS Aliases
var Scene = THREE.Scene;
var Renderer = THREE.WebGLRenderer;
var PerspectiveCamera = THREE.PerspectiveCamera;
var BoxGeometry = THREE.BoxGeometry;
var CubeGeometry = THREE.CubeGeometry;
var PlaneGeometry = THREE.PlaneGeometry;
var SphereGeometry = THREE.SphereGeometry;
var Geometry = THREE.Geometry;
var AxisHelper = THREE.AxisHelper;
var LambertMaterial = THREE.MeshLambertMaterial;
var MeshBasicMaterial = THREE.MeshBasicMaterial;
var Material = THREE.Material;
var Mesh = THREE.Mesh;
var Object3D = THREE.Object3D;
var SpotLight = THREE.SpotLight;
var PointLight = THREE.PointLight;
var AmbientLight = THREE.AmbientLight;
var Control = objects.Control;
var GUI = dat.GUI;
var Color = THREE.Color;
var Vector3 = THREE.Vector3;
var Face3 = THREE.Face3;
var Point = objects.Point;
var CScreen = config.Screen;
var Control2 = objects.Control;
//Custom Game Objects
var gameObject = objects.gameObject;
var loader = new THREE.JSONLoader();
var animation;
var scene;
var renderer;
var camera;
var axes;
var cube;
var plane;
var sphere;
var ambientLight;
var spotLight;
var control;
var control2;
var gui;
var stats;
var step = 0;
var cubeGeometry;
var armeMaterial;
var arm2eMaterial;
var legMaterial;
var leg2Material;
var headMaterial;
var cubeMaterial;
var ambientColour;
var head;
var leg;
var leg2;
var arm;
var arm2;
var legGeometry;
var armGeometry;
var headGeometry;
var material = new THREE.MeshPhongMaterial({ map: THREE.ImageUtils.loadTexture('texture/pl_sun.jpg') });
var texture = new THREE.MeshPhongMaterial({ map: THREE.ImageUtils.loadTexture('texture/crate.jpg') });
var i;
var j;
function init() {
    // Instantiate a new Scene object
    scene = new Scene();
    setupRenderer(); // setup the default renderer
    setupCamera(); // setup the camera
    // add an axis helper to the scene
    axes = new AxisHelper(10);
    scene.add(axes);
    console.log("Added Axis Helper to scene...");
    //Add a Plane to the Scene
    // plane = new gameObject(
    //   new PlaneGeometry(16, 16, 1, 1),material, 0, 0, 0);
    plane = new gameObject(new PlaneGeometry(20, 40, 1, 1), texture, 1, 1, 1);
    plane.rotation.x = -0.5 * Math.PI;
    scene.add(plane);
    console.log("Added Plane Primitive (Floor) to Scene");
    //
    //
    plane.rotation.x = -0.5 * Math.PI;
    scene.add(plane);
    console.log("Added Plane Primitive to scene...");
    //Add a Cube to the Scene
    ambientColour = "#0c0c0c";
    cubeMaterial = new LambertMaterial(ambientColour);
    legMaterial = new LambertMaterial(ambientColour);
    leg2Material = new LambertMaterial(ambientColour);
    arm2eMaterial = new LambertMaterial(ambientColour);
    armeMaterial = new LambertMaterial(ambientColour);
    headMaterial = new LambertMaterial(ambientColour);
    //cubeMaterial = new LambertMaterial({color:0x00ff00});
    cubeGeometry = new CubeGeometry(2, 3, 2);
    cube = new Mesh(cubeGeometry, cubeMaterial);
    cube.castShadow = true;
    cube.receiveShadow = true;
    cube.position.set(0, 5, 0);
    legGeometry = new CubeGeometry(1, 3, 1);
    leg = new Mesh(legGeometry, legMaterial);
    leg.castShadow = true;
    leg.receiveShadow = true;
    leg.position.set(0.8, -3, 0);
    leg2 = new Mesh(legGeometry, leg2Material);
    leg2.castShadow = true;
    leg2.receiveShadow = true;
    leg2.position.set(-0.8, -3, 0);
    armGeometry = new CubeGeometry(1, 2, 1);
    arm = new Mesh(armGeometry, arm2eMaterial);
    arm.castShadow = true;
    arm.receiveShadow = true;
    arm.position.set(1.5, 0.5, 0);
    arm2 = new Mesh(armGeometry, armeMaterial);
    arm2.castShadow = true;
    arm2.receiveShadow = true;
    arm2.position.set(-1.5, 0.5, 0);
    headGeometry = new CubeGeometry(1, 1, 1);
    head = new Mesh(headGeometry, headMaterial);
    head.castShadow = true;
    head.receiveShadow = true;
    head.position.set(0, 2, 0);
    cube.add(leg);
    cube.add(leg2);
    cube.add(arm2);
    cube.add(arm);
    cube.add(head);
    scene.add(cube);
    console.log("Added Cube Primitive to scene...");
    var render = function () {
        requestAnimationFrame(render);
        arm.rotation.x += 0.05;
        arm2.rotation.x += 0.05;
        //renderer.render(scene, camera);
    };
    render();
    //  ambientLight = new AmbientLight(ambientColour);
    // Add an AmbientLight to the scene
    ambientLight = new AmbientLight(0x090909);
    scene.add(ambientLight);
    console.log("Added an Ambient Light to Scene");
    // Add a SpotLight to the scene
    spotLight = new SpotLight(0xffffff);
    spotLight.position.set(-40, 60, 10);
    spotLight.rotation.set(-0.8, 42.7, 19.5);
    spotLight.castShadow = true;
    scene.add(spotLight);
    console.log("Added a SpotLight Light to Scene");
    // add controls
    gui = new GUI();
    //  control = new Control(0.05);
    control = new Control(0.00, ambientColour);
    addControl(control);
    // Add framerate stats
    addStatsObject();
    console.log("Added Stats to scene...");
    document.body.appendChild(renderer.domElement);
    gameLoop(); // render the scene	
    window.addEventListener('resize', onResize, false);
}
function onResize() {
    camera.aspect = CScreen.RATIO;
    //camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    //renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setSize(CScreen.WIDTH, CScreen.HEIGHT);
}
function addControl(controlObject) {
    gui.add(controlObject, 'rotationSpeedx', -0.5, 0.5);
    gui.add(controlObject, 'rotationSpeedy', -0.5, 0.5);
    gui.add(controlObject, 'rotationSpeedz', -0.5, 0.5);
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { cubeMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { legMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { leg2Material.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { arm2eMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { armeMaterial.color = new Color(color); });
    gui.addColor(controlObject, 'ambientColour').onChange(function (color) { headMaterial.color = new Color(color); });
    /* armeMaterial = new LambertMaterial(ambientColour);*/
}
function addStatsObject() {
    stats = new Stats();
    stats.setMode(0);
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.left = '0px';
    stats.domElement.style.top = '0px';
    document.body.appendChild(stats.domElement);
}
// Setup main game loop
function gameLoop() {
    stats.update();
    cube.rotation.x += control.rotationSpeedx;
    cube.rotation.y += control.rotationSpeedy;
    cube.rotation.z += control.rotationSpeedz;
    // render using requestAnimationFrame
    requestAnimationFrame(gameLoop);
    // render the scene
    renderer.render(scene, camera);
}
// Setup default renderer
function setupRenderer() {
    renderer = new Renderer();
    renderer.setClearColor(0xEEEEEE, 1.0);
    renderer.setSize(CScreen.WIDTH, CScreen.HEIGHT);
    //renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    console.log("Finished setting up Renderer...");
}
// Setup main camera for the scene
function setupCamera() {
    camera = new PerspectiveCamera(45, config.Screen.RATIO, 0.1, 1000);
    //camera = new PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.x = 0.6;
    camera.position.y = 16;
    camera.position.z = -20.5;
    camera.lookAt(new Vector3(0, 0, 0));
    console.log("Finished setting up Camera...");
}
//# sourceMappingURL=game.js.map