/// <reference path="../../typings/tsd.d.ts" />
/// <reference path="../config/screen.ts"/>
/// <reference path="../objects/point.ts"/>
/// <reference path="../objects/control.ts" />
/// <reference path="../objects/gameobject.ts"/>